from setuptools import setup

setup(
    name='fabricmassevac',
    version='0.1',
    packages=['.app'],
    python_requires=">=3.10"
)